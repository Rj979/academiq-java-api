package com.academiq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademiQJavaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcademiQJavaApiApplication.class, args);
	}

}
