package com.academiq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademiqApplication {
    public static void main(String[] args) {
        SpringApplication.run(AcademiqApplication.class, args);
    }
}
